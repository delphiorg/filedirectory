//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainMongoGrid.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonOpenClick(TObject *Sender)
{
  FDMongoQuery1->Close();
  FDMongoQuery1->FieldDefs->Clear();

  FDMongoQuery1->QMatch = EditMatch->Text;
  FDMongoQuery1->QSort = EditSort->Text;
  FDMongoQuery1->QProject = EditProjection->Text;
  FDMongoQuery1->Open();

  if (FDMongoQuery1->FindField("address.coord") != NULL) {
	dsCoords->DataSet = ((TDataSetField*)FDMongoQuery1->FieldByName("address.coord"))->NestedDataSet;
  }
  if (FDMongoQuery1->FindField("grades") != NULL) {
	dsGrades->DataSet = ((TDataSetField*)FDMongoQuery1->FieldByName("grades"))->NestedDataSet;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  FDConnection1->Open();
  FCon = (TMongoConnection*)FDConnection1->CliObj;
  FEnv = FCon->Env;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
  FDConnection1->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
  TMongoCollection *oCol;
  oCol = FCon->GetCollection("test", "restaurants");
  oCol->RemoveAll();

  TFDTextFile *oText;
  oText = new TFDTextFile("..\\..\\restaurants.json", True, False, ecANSI, elWindows);
  TMongoDocument *oDoc = FEnv->NewDoc();

  try
  {
	int n = 0;
	ButtonOpen->Enabled = False;
	oCol->BeginBulk();
	try
	{
	  while (true)
	  {
		UnicodeString s = oText->ReadLine();
		if (s == "") break;
		oDoc->AsJSON = s;
		oCol->Insert(oDoc);
		n++;
	  }
	  ButtonOpen->Enabled = True;
	  oCol->EndBulk();
	  ShowMessage(Format("Imported %d documents.", ARRAYOFCONST((n))));
	}
	catch (Exception &E)
	{
	  oCol->CancelBulk();
	}
  }
  __finally
  {
	oDoc->Free();
	oText->Free();
  }


}
//---------------------------------------------------------------------------

