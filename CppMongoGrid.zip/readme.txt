You need to install and start a local MongoDB instance.

http://docwiki.embarcadero.com/RADStudio/Seattle/en/Connect_to_MongoDB_Database_(FireDAC)

This attemps to connect to the Test database and queries against the Restuarants collection. 
You can load those with the Load Data button to load from the Restuarants.json file.
