This demonstrates the minimum of an Android Service with Object Pascal / Delphi.

Local Service with START_STICKY.

More information:

http://docwiki.embarcadero.com/RADStudio/Seattle/en/Creating_Android_Services

See the video https://youtu.be/0mD3WLK8FYc

