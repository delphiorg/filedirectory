package jim.test.android.http1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map.Entry;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class http1Activity extends Activity {
	String TAG = "http1Activity";
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        	Log.d(TAG, "headButton");
	        ((Button) findViewById(R.id.headButton)).setOnClickListener(new View.OnClickListener() {
	            public void onClick(View v) {
	            	clear();
	                testHead();
	            }
	        });
	        
        	Log.d(TAG, "getButton");
	        ((Button) findViewById(R.id.getButton)).setOnClickListener(new View.OnClickListener() {
	            public void onClick(View v) {
	            	clear();
	                testGet();
	            }
	        });        
	        
        	Log.d(TAG, "getButton");
	        ((Button) findViewById(R.id.rngButton)).setOnClickListener(new View.OnClickListener() {
	            public void onClick(View v) {
	            	clear();
	                testRange();
	            }
	        });        
        
        	Log.d(TAG, "multiButton");
	        ((Button) findViewById(R.id.multiButton)).setOnClickListener(new View.OnClickListener() {
	            public void onClick(View v) {
	            	clear();
	                testMulti();
	            }
	        });        
        	
        	Log.d(TAG, "imgButton");
	        ((Button) findViewById(R.id.imgButton)).setOnClickListener(new View.OnClickListener() {
	            public void onClick(View v) {
	            	clear();
	            	
	            	ImageView img = (ImageView)findViewById(R.id.imageView1);
	            	img.setImageBitmap(getBitmapFromURL(imgUrl));        	
	            }
	        });       
        	
        	Log.d(TAG, "cookieButton");
	        ((Button) findViewById(R.id.cookieButton)).setOnClickListener(new View.OnClickListener() {
	            public void onClick(View v) {
	            	clear();
	            	
	    			testCookies();	            	
	            }
	        });       
			
			//testPost();
    }
    
    String url = "http://davinciunltd.com/http/httptestfile.txt";
    String imgUrl = "http://davinciunltd.com/http/android-150x150.jpg";
    String charset = "UTF-8";
    
    public void testHead(){
		try {
			
	    	HttpURLConnection connection;
			connection = (HttpURLConnection)new URL(url).openConnection();
			connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.2.3) Gecko/20100401"); // Do as if you're using Firefox 3.6.3.
	    	connection.setRequestMethod("HEAD");
	    	//InputStream response = connection.getInputStream();
	    	//String result = readString(response, charset);
	    	displayHeaders(connection);    	
	    	//disp(result + "\n");
    	
		} catch (Exception e) {
			e.printStackTrace();
		}    	
    }

	private void displayHeaders(HttpURLConnection connection) throws IOException {
    	int status = connection.getResponseCode();
    	disp("ResponseCode = " + String.valueOf(status));
		for (Entry<String, List<String>> header : connection.getHeaderFields().entrySet()) {
			disp(header.getKey() + "=" + header.getValue());
		}
	}
    
    public void testCookies() {
		try {

			String google = "http://google.com/";
			disp("Cookies from google.com");
			
			// Cookie manager doesn't always work . ... 
			//CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));
			
			HttpURLConnection connection = (HttpURLConnection)new URL(google).openConnection();
	    	connection.connect();
	    	//displayHeaders(connection);	    	
	    	List<String> cookies = connection.getHeaderFields().get("Set-Cookie");
	    	for (String cookie : cookies){
	    		disp(cookie.split(";", 2)[0]);
	    	}
	    	
	    	// use those cookies again
	    	connection = (HttpURLConnection)new URL(google).openConnection();
	    	for (String cookie : cookies) {
	    	    connection.addRequestProperty("Cookie", cookie.split(";", 2)[0]);
	    	}
	    	connection.connect();
    	
		} catch (Exception e) {
			e.printStackTrace();
		}    	
    }
    
    public void testGet() {
		try {

	    	HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
	    	//connection.setRequestMethod("GET"); // Default
	    	InputStream response = connection.getInputStream();
	    	String result = readString(response, charset);
	    	displayHeaders(connection);    	
	    	disp("\n");
	    	disp(result + "\n");
	    	
		} catch (Exception e) {
			e.printStackTrace();
		}    	
    }
    
    public void testError() {
		try {

	    	HttpURLConnection connection = (HttpURLConnection)new URL("http://www.google.com/404").openConnection();
	    	connection.connect();
	    	InputStream response;
	    	
	    	int status = connection.getResponseCode();
	    	if (status < 200 || status > 299){
		    	response = connection.getErrorStream();	    		
	    	}
	    	else
	    	{
		    	response = connection.getInputStream();
	    	}
	    	
	    	String result = readString(response, charset);
	    	displayHeaders(connection);    	
	    	disp("\n");
	    	disp(result + "\n");
	    	
		} catch (Exception e) {
			e.printStackTrace();
		}    	
    }
    
    public void testRange() {
		try {

			HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
	    	connection.setRequestProperty("Range", "bytes=115-154");
	    	InputStream response = connection.getInputStream();    	
	    	String result = readString(response, charset);
	    	
	    	displayHeaders(connection);	    	
	    	disp(result);
	    	
		} catch (Exception e) {
			e.printStackTrace();
		}	
    }

    public void testMulti() {
		try {

			HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
	    	connection.setRequestProperty("Range", "bytes=127-127,115-154");
	    	InputStream response = connection.getInputStream();
	    	String result = readString(response, charset);
	    	
	    	displayHeaders(connection);	    	
	    	disp(result + "\n");
	    	
		} catch (Exception e) {
			e.printStackTrace();
		}
    }  

    
    public void testPost() throws MalformedURLException, IOException{
        String param1 = "value1";
        String param2 = "value2";
        
        String query = String.format("param1=%s&param2=%s", 
        	     URLEncoder.encode(param1, charset), 
        	     URLEncoder.encode(param2, charset));    	
    	
        HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
    	connection.setDoOutput(true); // Triggers POST.
    	connection.setRequestProperty("Accept-Charset", charset);
    	connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=" + charset);
    	// If you know the content lenght on a post, this sets streaming mode
    	//connection.setFixedLengthStreamingMode(contentLength);  
    	// otherwise for unknown lenght
    	connection.setChunkedStreamingMode(1024);
    	OutputStream output = null;
    	try {
    	     output = connection.getOutputStream();
    	     output.write(query.getBytes(charset));
    	} finally {
    	     if (output != null) try { output.close(); } catch (IOException logOrIgnore) {}
    	}
    	connection.connect();
    	//InputStream response = connection.getInputStream();    	
    }
    
    public void clear(){
    	EditText et = (EditText)findViewById(R.id.editText1);
    	et.setText("");    	
    }
    

    public void disp(String str){
    	EditText et = (EditText)findViewById(R.id.editText1);
    	StringBuilder sb = new StringBuilder();
  		sb.append(et.getText().toString());
    	sb.append(str + "\n" );
    	et.setText(sb.toString());
    }    
    
    public String readString(InputStream is, String encoding) throws IOException{
    	ByteArrayOutputStream into = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        for (int n; 0 < (n = is.read(buf));) {
            into.write(buf, 0, n);
        }
        into.close();
        return new String(into.toByteArray(), encoding);
    }
    
    public Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            
	    	displayHeaders(connection);	    	
            
            InputStream input = connection.getInputStream();            
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
  
}