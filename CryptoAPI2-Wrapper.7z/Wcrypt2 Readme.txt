--------------------------------------------------------
This document is Copyright � 1997-98 Project JEDI.
Visit the JEDI home page at:http://www.delphi-jedi.org/
--------------------------------------------------------

--------------------------------------------------------
CryptoApi version 2 (sdk date 12/1997)
Delphi binding version 1.0.2
--------------------------------------------------------

structure of package:

wcrypt2.pas      -> Delphi binding.
readme.txt       -> this file.
CryptFuncDll.txt -> list of exported function
                    from : ADVAPI32.DLL, CRYPT32.DLL, SOFTPUB.DLL
  
NOTE: 
TODO: testing.
      
Massimo Maria Ghisalberti
O.B.you!
obyou@tin.it
nissl@tin.it (personal)
(-- JEDI Project JediCore Conversion Member --)