For more information see:

http://www.delphi.org/robot-rage/

-- Setting up UT3 --

You will need to install patch v1.2 (or above) for UT3 to make it compatible with UT3Bots. 

To compile the mod using the Tool you created above, you will need to configure UT3 to know about the mod.
Open the following file in notepad:
%userprofile%\Documents\My Games\Unreal Tournament 3\UTGame\Config\UTEditor.ini

At the bottom of that file there should be a [ModPackages] section.
You need to add a reference to the UT3Bots package at the end of that section:
ModPackages=UT3Bots
ModPackages=UT3BotsPathing

The section should end up looking something like:
[ModPackages]
ModPackagesInPath=..\UTGame\Src
ModOutputDir=..\UTGame\Unpublished\CookedPC\Script
ModPackages=UT3Bots
ModPackages=UT3BotsPathing

You will also need to copy the UT3Bots.ini file from the ServerMutator project and the 
UT3BotsPathing.ini file from the PathNodeMutator project into the following directory:
%userprofile%\Documents\My Games\Unreal Tournament 3\UTGame\Config\

To make all the different combinations of bot meshes and skins appear in the game you need to do one more step.
Open the following file in notepad:
%userprofile%\Documents\My Games\Unreal Tournament 3\UTGame\Config\UTGame.ini

Find the [UTGame.UTGame] section and edit the MaxCustomChars line to be 30:
[UTGame.UTGame]
<...other settings...>
MaxCustomChars=30


Place ServerMutator.dll & PathNodeMutator.dll file in

%userprofile%\Documents\My Games\Unreal Tournament 3\UTGame\Src\