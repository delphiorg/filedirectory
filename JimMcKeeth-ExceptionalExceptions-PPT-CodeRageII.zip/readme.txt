Presentation Copyright (c) 2007 by Jim McKeeth
For more information visit http://www.davinciunltd.com/code/exceptions