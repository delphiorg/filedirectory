Rainbow Image demo for Delphi
by Jim McKeeth
Copyright (c) 2007 by Jim McKeeth
http://www.davinciunltd.com/ 

Available for use under Mozilla Public License 1.1
http://www.mozilla.org/MPL/MPL-1.1.html

Demonstrates using HTTP range requests to download parts 
of multiple files and joins them together.  

Uses Indy 10, but could easily be adapted to Indy 9.

Normally you would want to download parts of the same file,
but for this demo is uses different color versions of the 
same image.

The images may be removed later if they become too much 
of a bandwith drain.  If they do then an updated demo
will be proveded which uses alternative image sources.

For more information and updates visit http://www.davinciunltd.com/ 