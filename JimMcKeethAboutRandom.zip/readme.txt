Read Me!

This is 4 entries for the contest

About.com Challenge: Fastest Unique Random Number Generator
  http://delphi.about.com/od/delphitips2009/qt/delphi-unique-random-number-generator-challenge.htm

Along with the entries is a DUnit test suite to verify the results.

It is written with Delphi 2009 and makes use of generics.
________________________________________________________________________________

Author:
  Jim McKeeth
  jim@mckeeth.org
  Washington, USA
  www.Delphi.org

  I certify that I am the author or sole owner of the material I am submitting
  to About.com. About.com and its licensees may reproduce, distribute, publish,
  display, edit, modify, create derivative works and otherwise use the material
  for any purpose in any form and on any media. I agree to indemnify About.com
  for all damages and expenses that may be incurred in connection with the
  material.
 
________________________________________________________________________________

Copyright (c) 2009, Jim McKeeth
jim@mckeeth.org
www.Delphi.org
www.DavinciUnltd.com
All rights reserved.


Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, 
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, 
      this list of conditions and the following disclaimer in the documentation 
      and/or other materials provided with the distribution.
    * Neither the name of the Jim McKeeth nor the names of its contributors may 
      be used to endorse or promote products derived from this software without 
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
________________________________________________________________________________

Notes about the contest:

  Judging criteria:
    1) Solve problem
    2) No memory leaks
    3) Clean and simple
    4) No unnecessary code lines
    5) Speed
    6) Subjective judgment of code
  
  Observations:
    1) The article provides the array length and max value even though the
       procedure signature allows for variable lengths and values.
       a) Is this (length=100 & maxValue=1000) the only test case?
       b) Can we optimize for these parameters?
       c) Do we need to test for incorrect parameters?
       d) Can we eliminate the Int64 for Integer since the test case does not
          require it, thus improving performance?
    2) No unnecessary code lines is rather subjective.  Possible meanings:
       a) The extreme would be putting all code on one line.
       b) Eliminate all tests and unlikely code paths.
       c) No blank lines?
       d) Favor simplicity over robustness & ease of readability?
    3) How random is random?
       a) The randomness is not specified, nor the method to use.
       b) Is Delphi's built in random generation system sufficient?
       c) Is building our own random algorithm necessary or even allowed?
       d) Is previously generated random numbers sufficient?
    4) How is speed measured?
       a) Is the runtime calculated through code analysis?
       b) Will the target system have multiple cores? (Should we thread?)
       c) What the time vs. space trade-offs can be made for better speed?
          1) Pre-generate random tables based on the constant nature of test?
    5) Minimum required random value is 1 not 0!
    6) RandomRange includes the lower bound, but not the upper bound.
    
________________________________________________________________________________

Notes on each entry:

Each entry has notes in the header explaining it and a brief analysis.  


Entry 1
  JimMcKeethAboutRandomContest1.pas
  
  This one uses a divide and conquer approach.  It divides the max value by the 
  required number of values and generates a number in that range.  It calculates
  the sub-range after each new number is generated.  This results in a slight
  bias towards lower numbers, but all numbers are possible.
  
Entry 2
  JimMcKeethAboutRandomContest2.pas
  
  This is the slow approach.  It generates a random number and then checks
  a list of previously generated numbers to see if it is already used.  With 
  each number that is generated it goes through the whole list, which 
  progressively gets longer.  No biases.
  
Entry 3
  JimMcKeethAboutRandomContest3.pas
  
  This one takes advantage of the fact that the contest was rather vague about 
  the method and specifically defined the maxValue and size of the array that 
  would be used.  It makes use of 10 previously defined random arrays.  This 
  arrays were generated randomly, and so are random, thus meeting the 
  requirement.  It is very fast.
  
Entry 4
  JimMcKeethAboutRandomContest4.pas
  
  This one generates a sorted random list through an insertion process.  A new
  random number is inserted in between two other numbers at random.  There 
  should be no biases and it is very fast.
  
  It seems to fail the non-adjacent test for small value ranges.  This is an
  artifact of the internal random routine as the algorithm does not favor
  this adjacency, nor does this happen in larger value ranges.

Common file:  
  JimMcKeethAboutRandomContest_Common.pas
  
  Int64 capable random routines and a parameter input validation for each of the
  entries.
  
Each entry has its own unit test that descends from a common unit test.  They
were tested beyond the scope of the defined value and range (which was when it
was discovered that the built in Random routines do not support Int64!) but the
tests are currently only instrumented to test on the defined criteria.  

The tests for max, min and adjacency iterate 10,000 times until it finds one 
that passes.  Because they are random numbers it cannot guarantee that any of 
these tests will pass every time (in fact they shouldn't every time) but by 
testing to make sure they pass occasionally it can verify that the full random
space is exploited.    

Other possibilities:
 
The insert in Method 4 makes use of a move during the insert.  Seems like if we
used a linked list instead then we could bypass the move, but a linked list is
not indexable.  It would be impractical to allocate a sparse array for the
entire maxValue range for sufficiently large values, so we would end up with
another list structure storing indexes, and then the benefit would probably be
lost.

If method 4 was reimplemented to not rely on the build in TList<T> so it had
access to the internal storage array, then a move from one array to the other
instead of a loop would probably be faster. . . .  