Turbo Power LockBox updated to 2.08 for Delphi RAD Studio 2007

Original licenses intact.  

Updated as part of the Implementing Cryptography session for CodeRage II in November 2007. 

For more information visit 
http://www.davinciunltd.com/code/delphi-cryptography/