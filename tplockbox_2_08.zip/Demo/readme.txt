Demo for Turbo Power LockBox 2.08 in Delphi RAD Studio 2007
(Notice odd behavior using RSA)

Copyright (c) 2007 by Jim McKeeth

Available under the MPL 1.1 license
http://www.mozilla.org/MPL/MPL-1.1.html
(other terms available)

Created as part of the Implementing Cryptography session for CodeRage II in November 2007. 

For more information visit 
http://www.davinciunltd.com/code/delphi-cryptography/