See http://delphi.org/?p=1346 and http://delphi.org/coderage8
for more information

Some example protocols

http, tel, sms, fb, mailto, twitter, geo, etc.

Example URLs

Common to both iOS & Android
http://www.embarcadero.com/
tel://(415)834-3131
sms://1234
http://twitter.com/coderage
mailto://jim.mckeeth@embarcadero.com
twitter://user?screen_name=coderage
fb://profile/34960937498
        (get the UID from http://graph.facebook.com/embarcaderotech )

iOS Specific
http://maps.apple.com?q=5617 Scotts Valley Drive, Scotts Valley, CA 95066
(this needs the URL encode)

Android
content://contacts/people/
geo://0,0?q=5617 Scotts Valley Drive, Scotts Valley, CA 95066
geo://46.191200, -122.194400
  (I think this one doesn't like the URLEncode)

