Exceptions demos from November 2007 CodeRage II presentation by Jim McKeeth
For more information visit
http://www.davinciunltd.com/code/exceptions/