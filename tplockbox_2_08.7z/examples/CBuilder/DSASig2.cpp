//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "DSASig2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TdlgKeySize *dlgKeySize;
//---------------------------------------------------------------------------
__fastcall TdlgKeySize::TdlgKeySize(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
