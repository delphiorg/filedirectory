Steps to compile this demo.

1.- Open RemoteDemo.groupproj
2.- Compile android service: libRemoteService.so
	There is a bug in Seattle 10.0 with the java templates. To fix this issue you have to follow these steps:
	a) Compile android service: libRemoteService.so, you will get a javac error
	b) Open the generated RemoteService.template.java 
	c) replace: 
		private final String libraryName = "<%ServiceName%>";
		with:
		private final String baseLibraryName = "<%ServiceName%>";

3.- Add android service to AppRemoteHost
    a) Active AppRemoteHost project
    b) Expand Target Platforms node
	c) Active Android platform
	d) Right click on Android platform node
	c) Click on Add Android Service... 
	e) Select RemoteService folder, click Next
	f) You have to see  libRemoteService.so, RemoteService.jar and RemoteServiceUnit.pas files. Click finish.
4.- Compile AppRemoteHost
	There is a bug in Seattle 10.0 with the AndroidManifest.xml generated. To fix this issue you have to follow these steps:
	a) Open AppRemoteHost\Android\Debug\AndroidManifest.xml
	b) Copy <service android:exported="false" android:name="com.embarcadero.services.RemoteService" /> to clipboard (Ctrl + c)
	c) Open AppRemoteHost\AndroidManifest.template.xml
	d) Replace <%activity%> with
		<service android:exported="false" android:name="com.embarcadero.services.RemoteService" />  (Ctrl + v)
	e) Change android:exported="false" to android:exported="true"
5.	Run AppRemoteHost
6.	Run AppRemoteExternal to check that you can connect to the remote service
