//---------------------------------------------------------------------------

#ifndef HashCodeH
#define HashCodeH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Edit.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.Memo.hpp>
#include <FMX.Objects.hpp>
#include <FMX.ScrollBox.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>
#include <System.Hash.hpp>

//---------------------------------------------------------------------------
class THashForm : public TForm
{
__published:	// IDE-managed Components
	TMemo *EditMessage;
	TSplitter *Splitter1;
	TVertScrollBox *ScrollBox1;
	TLayout *Layout1;
	TLabel *Label14;
	TLine *Line5;
	TLine *Line4;
	TEdit *EditBobJenkins;
	TLabel *Label13;
	TLabel *Label12;
	TLine *Line3;
	TLabel *Label11;
	TLabel *Label10;
	TEdit *EditMD5;
	TLine *Line2;
	TLabel *Label9;
	TLabel *Label8;
	TLine *Line1;
	TLabel *Label7;
	TEdit *Edit512;
	TLabel *Label6;
	TEdit *Edit512224;
	TLabel *Label5;
	TEdit *Edit512256;
	TEdit *Edit256;
	TLabel *Label4;
	TLabel *Label3;
	TEdit *Edit384;
	TLabel *Label2;
	TEdit *Edit224;
	TLabel *Label1;
	TEdit *EditSha1;
	void __fastcall EditMessageChange(TObject *Sender);
	void __fastcall UpdateHashes();
	void __fastcall EditMessageKeyUp(TObject *Sender, WORD &Key, System::WideChar &KeyChar,
          TShiftState Shift);
	void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall THashForm(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE THashForm *HashForm;
//---------------------------------------------------------------------------
#endif
