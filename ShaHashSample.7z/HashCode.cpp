// Hash Sample by Jim McKeeth with RAD Studio 10.2.3
// https://community.embarcadero.com/blogs/entry/sha-hash-with-c-builder-and-delphi

//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "HashCode.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
THashForm *HashForm;
//---------------------------------------------------------------------------
__fastcall THashForm::THashForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall THashForm::UpdateHashes()
{
	EditSha1->Text = THashSHA1::GetHashString(EditMessage->Text);
	Edit224->Text = THashSHA2::GetHashString(EditMessage->Text, THashSHA2::TSHA2Version::SHA224);
	Edit256->Text = THashSHA2::GetHashString(EditMessage->Text, THashSHA2::TSHA2Version::SHA256);
	Edit384->Text = THashSHA2::GetHashString(EditMessage->Text, THashSHA2::TSHA2Version::SHA384);
	Edit512->Text = THashSHA2::GetHashString(EditMessage->Text, THashSHA2::TSHA2Version::SHA512);
	Edit512224->Text = THashSHA2::GetHashString(EditMessage->Text, THashSHA2::TSHA2Version::SHA512_224);
	Edit512256->Text = THashSHA2::GetHashString(EditMessage->Text, THashSHA2::TSHA2Version::SHA512_256);
	EditMD5->Text = THashMD5::GetHashString(EditMessage->Text);
	EditBobJenkins->Text = THashBobJenkins::GetHashString(EditMessage->Text);
}
//---------------------------------------------------------------------------
void __fastcall THashForm::EditMessageChange(TObject *Sender)
{
	UpdateHashes();
}
//---------------------------------------------------------------------------
void __fastcall THashForm::EditMessageKeyUp(TObject *Sender, WORD &Key, System::WideChar &KeyChar,
		  TShiftState Shift)
{
	UpdateHashes();
}
//---------------------------------------------------------------------------
void __fastcall THashForm::FormShow(TObject *Sender)
{
	UpdateHashes();
}
//---------------------------------------------------------------------------

