http://www.davinciunltd.com/2007/11/crashing-like-vb/
http://www.davinciunltd.com/code/exceptions

--------------

This shows how to bypass Delphi's global exception handler and raise an
exception to be hanled by the OS.  

Be sure to check out the code in the DPR too!

--------------

I always thought Delphi�s global exception handler was a great feature. It
allows your program to continue after an otherwise unhandled exception 
would have caused it to terminate. Typically in a serious application you 
would assign your own global exception handler, or used one of the great 
3rd part exception handlers like madExcept or Exceptional Magic (I love 
that name!) They both provide a nice dialog, stack trace, logging and 
reporting.

Well it turns out that if you want to be Microsoft Windows Vista Logo 
certified, then you need to crash your application on certain exceptions.

	Applications must handle only exceptions that are known and 
	expected, and Windows Error Reporting must not be disabled. If a 
	fault (such as an Access Violation) is injected into an 
	pplication, the application must allow Windows Error Reporting to 
	report this crash. (from requirement 3.2 Resilient Software: 
	Eliminate Application Failures)

Microsoft�s rational for this requirement is the ISV will receive the error 
report Microsoft collects for them. I guess most software developers don�t 
have access to tools like we do in Delphi to catch exceptions and log them 
for us.

So short of tossing out the Forms unit and writing everything from scratch, 
how can you get around the usefulness of the global exception handler.
