The interface is a tree view of matches with the robots in the match 
as the children of the match.

+ Team Death Match
|---Robot
|---Robot
|---Robot
|---Robot
+ Death Match
|---Robot
|---Robot


All the functions are under the right click menu.
* Start Battle - Launches the match
* New Battle - Creates a new match with no robots
* Change Arena - Moves to a new map
* Battle Options - Configure match
* Delete Battle - Delete configured map
-----
* Insert Bot - Add a new bot to the match
* Edit Bot - Edit the source code for the bot (if editable)
* Create Bot - Make a new bot
* Set Team 1 - Place bot on Team 1
* Set Team 2 - Place bot on Team 2
* Remove Bot - Remove the bot from the match

Notice that some of the options will be disabled based on the 
context of where the menu was launched from.


