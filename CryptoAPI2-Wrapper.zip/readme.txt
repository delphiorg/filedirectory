This is a collection of wrapper classes for the wcrypt2.pas header translation for the Microsoft Crypto API.  

The demo application also covers the Isaac random number generator.  

Also included is Isaac.pas and variations from http://sebsauvage.net/isaac/

Code by Jim McKeeth Copyright (c) 2007 by Jim McKeeth 
Other code copyright by original authors.

Available under the MPL 1.1 license
http://www.mozilla.org/MPL/MPL-1.1.html
(other terms available)

Created as part of the Implementing Cryptography session for CodeRage II in November 2007. 

For more information visit 
http://www.davinciunltd.com/code/delphi-cryptography/