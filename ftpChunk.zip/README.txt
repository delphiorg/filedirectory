FTP Chunker for Delphi
by Jim McKeeth
Copyright (c) 2007 by Jim McKeeth
http://www.davinciunltd.com/ 

This is the FTP Chunker class and example I wrote for my Code Rage 2007 presentation.  

It allows the retrieval of any part of a file via FTP.  The FTP server must support the REST command, which most do.

Uses Indy 9 - Written and tested on Delphi 2007

Available for use under Mozilla Public License 1.1
http://www.mozilla.org/MPL/MPL-1.1.html
