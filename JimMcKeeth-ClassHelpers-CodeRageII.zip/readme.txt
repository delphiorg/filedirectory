Class Helpers demo code from the CodeRage II session Class Helpers: Friend or Foe by Jim McKeeth.

For more information visit:
http://www.davinciunltd.com/code/delphi-class-helpers/