//---------------------------------------------------------------------------

#include <fmx.h>
#include <System.Threading.hpp>
#pragma hdrstop

#include "MainUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm4 *Form4;
//---------------------------------------------------------------------------
__fastcall TForm4::TForm4(TComponent* Owner)
	: TForm(Owner)
{
}

class TCppSync : public TCppInterfacedObject<TThreadProcedure> {
  int &lValue;
  TLabel *Label;
public:
  TCppSync(int &l, TLabel *lbl) : lValue(l), Label(lbl)
  {}
  void __fastcall Invoke() {
	Label->Text = String(lValue);
  }
};

class TCppTask : public TCppInterfacedObject<TProc> {
  int &lValue;
  TLabel *Label;
public:
  TCppTask(int &l, TLabel *lbl) : lValue(l), Label(lbl)
  {}
  void __fastcall Invoke() {
	Sleep(3000);
	lValue = Random(10);
	TThread::Synchronize(0, _di_TThreadProcedure(new TCppSync(lValue, Label)));
  }
};

//---------------------------------------------------------------------------
void __fastcall TForm4::Button1Click(TObject *Sender)
{
  Label1->Text = "--";
  TTask::Run(_di_TProc(new TCppTask(lValue, Label1)));
}
//---------------------------------------------------------------------------
