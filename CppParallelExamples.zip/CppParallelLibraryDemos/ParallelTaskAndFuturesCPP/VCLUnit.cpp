//---------------------------------------------------------------------------

#include <vcl.h>
#include <System.Threading.hpp>
#pragma hdrstop

#include "VCLUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}

class TCppSync : public TCppInterfacedObject<TThreadProcedure> {
  int &lValue;
  TLabel *Label;
public:
  TCppSync(int &l, TLabel *lbl) : lValue(l), Label(lbl)
  {}
  void __fastcall Invoke() {
	Label->Caption = String(lValue);
  }
};

class TCppTask : public TCppInterfacedObject<TProc> {
  int &lValue;
  int sleepValue;
  TLabel *Label;
public:
  TCppTask(int &l, int s, TLabel *lbl) : lValue(l), sleepValue(s), Label(lbl)
  {}
  void __fastcall Invoke() {
	Sleep(sleepValue);
	lValue = Random(10);
	// Do Not do this if you are using a Wait All
	// The tasks will complete their sleeping and than wait
	// for the main app thread which is waiting for task completion
	// TThread::Synchronize(0, _di_TThreadProcedure(new TCppSync(lValue, Label)));
	// use something like
	// TInterlocked::Add(mValue, lValue);
  }
};

//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  // not a thread safe snippet

  Label1->Caption = "--";
  lValue = 0;
  _di_ITask aTask = TTask::Create(_di_TProc(new TCppTask(lValue, 3000, Label1)));
  aTask->Start();
  Label1->Caption = IntToStr(lValue);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
	_di_ITask tasks[2];

	tasks[0] = TTask::Create(_di_TProc(new TCppTask(lValue, 3000, Label1)));
	tasks[0]->Start();

	tasks[1] = TTask::Create(_di_TProc(new TCppTask(lValue, 5000, Label1)));
	tasks[1]->Start();

	TTask::WaitForAll(tasks,(sizeof(tasks)/sizeof(tasks[0])-1));
	ShowMessage ("All done! "+IntToStr(lValue));

}
//---------------------------------------------------------------------------

/*
int ComputeSomething()
{
  int Result = 0;
  for (int I=0;I++;I<10000) {
	Result = Result + Round(Sqrt(I));
  }
  return Result;
}

*/


void __fastcall TForm1::Button3Click(TObject *Sender)
{

/*
  // futures
  _di_IFuture OneValue;
  int OtherValue;
  int Total;

  OneValue = TTask::Future<Integer>
  (function: Integer
	begin
	  Result = ComputeSomething();
	end);
  Memo1->Lines->Add(_delphiRttiTRttiEnumerationType.
	GetName<TTaskStatus>(OneValue.Status));

  OtherValue = ComputeSomething();
  Memo1->Lines->Add(TRttiEnumerationType.
	GetName<TTaskStatus>(OneValue.Status));

  Total := OtherValue + OneValue.Value;
  Memo1.Lines.Add(TRttiEnumerationType.
	GetName<TTaskStatus>(OneValue.Status));

  // result
  Memo1->Lines->Add(IntToStr(Total));

*/

}
//---------------------------------------------------------------------------

