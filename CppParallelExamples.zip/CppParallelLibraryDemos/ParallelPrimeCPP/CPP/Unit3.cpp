//---------------------------------------------------------------------------

#include <fmx.h>
#include <System.Threading.hpp>
#include <System.Diagnostics.hpp>
#include <System.SyncObjs.hpp>
#include <System.SysUtils.hpp>
#pragma hdrstop

#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
	: TForm(Owner)
{
}


// test if a number is a prime number
bool IsPrime(int N) {
  bool aPrime = true;
  for (int Test = 2;Test<=N-1;Test++) {
	if (N % Test == 0) {
	  aPrime = false;
	  break; //jump out of the for loop
	}
  }
  return aPrime;
}


//---------------------------------------------------------------------------
void __fastcall TForm3::btnForLoopClick(TObject *Sender)
{
  // counts the prime numbers below a given value
  int Max = 50000; // 50K
  Tot = 0;
  System::Diagnostics::TStopwatch sw = System::Diagnostics::TStopwatch::Create();
  sw.Start();
  for (int I = 1;I<=Max;I++) {
	if (IsPrime(I)) {
	  Tot++;
	  // Application.ProcessMessages;
	}
  }
  sw.Stop();
  Memo1->Lines->Add (
	String().sprintf(L"Sequential For loop. Time (in milliseconds): %lld, Primes found: %d",
				sw.ElapsedMilliseconds,Tot)
  );
}

//---------------------------------------------------------------------------
// Parallel For Iterator Event Proc
void __fastcall TForm3::MyIteratorEvent(TObject* Sender, int AIndex)
{
	if (IsPrime(AIndex)) {
		TInterlocked::Increment(Tot);
	};
}

//---------------------------------------------------------------------------
void __fastcall TForm3::btnParallelForClick(TObject *Sender)
{
  // counts the prime numbers below a given value
  int Max = 50000; // 50K
  Tot = 0;
  System::Diagnostics::TStopwatch sw = System::Diagnostics::TStopwatch::Create();
  sw.Start();
  TParallel::For(NULL,1,Max,MyIteratorEvent);
  sw.Stop();
  Memo1->Lines->Add (
	String().sprintf(L"Parallel For loop. Time (in milliseconds): %lld, Primes found: %d",
				sw.ElapsedMilliseconds,Tot)
  );
}
//---------------------------------------------------------------------------
