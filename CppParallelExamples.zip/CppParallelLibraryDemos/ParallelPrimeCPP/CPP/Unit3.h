//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>
#include <FMX.Memo.hpp>
//---------------------------------------------------------------------------
class TForm3 : public TForm
{
__published:	// IDE-managed Components
	TGridPanelLayout *GridPanelLayout1;
	TButton *btnForLoop;
	TButton *btnParallelFor;
	TMemo *Memo1;
	void __fastcall btnForLoopClick(TObject *Sender);
	void __fastcall btnParallelForClick(TObject *Sender);
private:	// User declarations
	void __fastcall MyIteratorEvent(TObject* Sender, int AIndex);
public:		// User declarations
	int Tot;
	__fastcall TForm3(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm3 *Form3;
//---------------------------------------------------------------------------
#endif
