#include <System.Threading.hpp>
#include <System.TypInfo.hpp>
#include <stdio.h>
#if defined(__clang__)
 #include "MethodRef.h"
#endif

/*
There are actually 3 changes that you must make to the System.Threading.hpp header:

1) Rename IFuture.Start to IFuture.StartFuture
2) Rename TFuture.Start to TFuture.StartFuture
3) Remove/comment out the PASCALIMPLEMENTATION macro on the TFuture__1 definition

*/

namespace System {
 namespace Threading {

  template <typename T>
  __fastcall TFuture__1<T>::TFuture__1(System::TObject* Sender,
#if defined(__clang__)  
                                       TFunctionEvent__1<T> Event,
#else
                                       TFuture__1<T>::_dt_System_Threading_2 Event,
#endif                                       
                                       const System::DelphiInterface<System::Sysutils::TFunc__1<T> > Func,
                                       TThreadPool* APool) : TTask(Sender, RunEvent, 0, APool, 0, TCreateFlags())
  {
    this->FFunc = Func;
  }

  template <typename T>
  T __fastcall TFuture__1<T>::GetValue()
  {
    Wait();
    return FResult;
  }

  template <typename T>
  void __fastcall TFuture__1<T>::RunEvent(System::TObject* Sender)
  {
    if (FEvent)
      FResult = FEvent(Sender);
    else if (FFunc)
      FResult = FFunc->Invoke();
    else
      FResult = T();
  }

  template <typename T>
  System::DelphiInterface<IFuture__1<T> > __fastcall TFuture__1<T>::StartFuture(void)
  {
    _di_ITask task = TTask::Start();
    return System::DelphiInterface<IFuture__1<T> >();
  }
  
  template <class T>
  class TCppFuture : public TFuture__1<T>, public IFuture__1<T> {

    typedef TFuture__1<T> inherited;

    virtual T __fastcall GetValue(void)            { return inherited::GetValue(); }
    virtual bool __fastcall Wait(unsigned Timeout) { return inherited::Wait(Timeout); }
#ifndef _WIN64
    virtual bool __fastcall Wait(const System::Timespan::TTimeSpan &Timeout)
#else /* _WIN64 */
    virtual bool __fastcall Wait(const System::Timespan::TTimeSpan Timeout)
#endif /* _WIN64 */
                                                   { return inherited::Wait(Timeout); }
    virtual void __fastcall Cancel(void)           { return inherited::Cancel(); }
    virtual void __fastcall CheckCanceled(void)    { return inherited::CheckCanceled(); }
    virtual _di_ITask __fastcall Start(void)       { return TTask::Start(); }
    virtual TTaskStatus __fastcall GetStatus(void) { return inherited::GetStatus(); }
    virtual bool __fastcall ShouldExecute(void)    { return inherited::ShouldExecute(); }
    virtual void __fastcall ExecuteWork(void)      { return inherited::ExecuteWork(); }
    INTFOBJECT_IMPL_IUNKNOWN(inherited);

  public:
    TCppFuture(const System::DelphiInterface<System::Sysutils::TFunc__1<T> > Func) : 
             TFuture__1<T>(0, 
#if defined(__clang__)  
                           TFunctionEvent__1<T>(),
#else
                           TFuture__1<T>::_dt_System_Threading_2(),
#endif                                       
                           Func, TThreadPool::Default)
    {}

    System::DelphiInterface<IFuture__1<T> > __fastcall StartFuture()
    {
      return inherited::StartFuture();
    }
  };
  
  template<typename T>
  System::DelphiInterface<IFuture__1<T> > __fastcall TTask::Future(const System::DelphiInterface<System::Sysutils::TFunc__1<T> > Func) {

    TCppFuture<T>* _fut = new TCppFuture<T>(Func);
    _fut->StartFuture();
    return System::DelphiInterface<IFuture__1<T> >(static_cast<IFuture__1<T>* >(_fut));
  }
 }
}

#if defined(__clang__)
template<typename T> using _di_IFuture__1 = System::DelphiInterface<IFuture__1<T>>;
template<typename T> using _di_TFunc__1 = System::DelphiInterface<TFunc__1<T>>;
#endif

int main()
{
#if !defined(__clang__)
  class TCppFunc : public System::TCppInterfacedObject<System::Sysutils::TFunc__1<int> > {
  public:
    int __fastcall Invoke() {
      Sleep(1000);
      return 99;
    }
  };
  // Using Functor object
  System::DelphiInterface<IFuture__1<int> > fut = TTask::Future<int>(System::DelphiInterface<TFunc__1<int> >(new TCppFunc()));
#else
  // Using Lambda through helper XE7
  _di_IFuture__1<int> fut = TTask::Future<int>(MakeAnonMeth<_di_IFuture__1<int>>([]() -> int
                                              {
                                                Sleep(1000);
                                                return 99;
                                              }));
#endif
  printf("Status = %s\n", AnsiString(GetEnumName(__delphirtti(TTaskStatus), static_cast<int>(fut->Status))).c_str());
  printf("Status = %s\n", AnsiString(GetEnumName(__delphirtti(TTaskStatus), static_cast<int>(fut->Status))).c_str());
  int value = fut->GetValue();
  printf("Status = %s\n", AnsiString(GetEnumName(__delphirtti(TTaskStatus), static_cast<int>(fut->Status))).c_str());
  printf("Value = %d\n", value);
}