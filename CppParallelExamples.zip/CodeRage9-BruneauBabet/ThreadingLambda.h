//---------------------------------------------------------------------------

#ifndef ThreadingLambdaH
#define ThreadingLambdaH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
class TForm42 : public TForm
{
__published:	// IDE-managed Components
  TButton *Button1;
  TMemo *Memo1;
  TButton *Button2;
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
  int Value;
public:		// User declarations
  __fastcall TForm42(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm42 *Form42;
//---------------------------------------------------------------------------
#endif
