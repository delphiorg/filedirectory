#ifndef __METHODREF_H
#define __METHODREF_H

#include <System.hpp>
#include <type_traits>

template <typename INTF, typename T>
struct MethodReference : public MethodReference<INTF, decltype(&T::operator())>
{};

template <typename INTF, typename ClassType, typename ReturnType, typename... Args>
struct MethodReference<INTF, ReturnType (ClassType::*)(Args...) const>
{
  class impl : public TCppInterfacedObject<INTF>
  {
    ClassType fn;
  public:
    impl(ClassType &&_fn) : fn(std::move(_fn))
    {}
    virtual ReturnType __fastcall Invoke(Args... _args)
    {
      return fn(std::forward<Args>(_args)...);
    }
  };
};

template <typename INTF, typename T>
System::DelphiInterface<INTF> MakeAnonMeth(T &&t)
{
  typedef typename MethodReference<INTF,
                                   typename std::remove_reference<decltype(t)>::type>::impl impl;
  return new impl(std::forward<T>(t));
}

#endif