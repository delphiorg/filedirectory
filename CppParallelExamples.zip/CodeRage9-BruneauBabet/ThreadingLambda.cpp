//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <System.Threading.hpp>
#include "MethodRef.h"
#include "ThreadingLambda.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm42 *Form42;
//---------------------------------------------------------------------------
__fastcall TForm42::TForm42(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm42::Button1Click(TObject *Sender)
{
  TTask::Run(MakeAnonMeth<TProc>(
              [this]() -> void {
                const int iter = 5;
                for (int i=0; i<iter; ++i) {
                  Sleep(2000);
                  Value++;
                  TThread::Synchronize(0, MakeAnonMeth<TThreadProcedure>(
                    [this, i]() -> void {
                      String str(DateTimeToStr(Now()));
                      Memo1->Lines->Add(str+((i < (iter-1)) ? " - WORKING AWAY" :
                                                              " - DONE DONE!!!"));
                  }));
                }
              }));
}

//---------------------------------------------------------------------------
void __fastcall TForm42::Button2Click(TObject *Sender)
{
  Memo1->Lines->Add(DateTimeToStr(Now()) + String().sprintf(L" - Value = %d", Value));
}
//---------------------------------------------------------------------------
