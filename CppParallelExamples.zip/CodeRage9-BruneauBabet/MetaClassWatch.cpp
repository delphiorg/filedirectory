//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MetaClassWatch.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm42 *Form42;
//---------------------------------------------------------------------------
__fastcall TForm42::TForm42(TComponent* Owner)
  : TForm(Owner)
{
  srand(time(0));
}

static TObject* getRandObj()
{
  int i = rand() % 4;
  switch (i) {
    case 0: return new TStringList();
    case 1: return new TList__1<int>();
    case 2: return new TBits();
    case 3: return new TObject();
  }
  assert(false && "Unreachable");
  return 0;
}

//---------------------------------------------------------------------------
void __fastcall TForm42::Button1Click(TObject *Sender)
{
  TObject* obj = getRandObj();
  _EAX = reinterpret_cast<unsigned>(obj);
  ShowMessage((char*)((unsigned*)(*((unsigned**)obj)))[-14]);
  delete obj;
}
//---------------------------------------------------------------------------
