//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DelphiException.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm42 *Form42;
//---------------------------------------------------------------------------
__fastcall TForm42::TForm42(TComponent* Owner)
  : TForm(Owner)
{
}

static int compute(int i, int j)
{
  return i ? i*j : j/i;
}

//---------------------------------------------------------------------------
void __fastcall TForm42::Button1Click(TObject *Sender)
{
  try {
    compute(0, 10);
  }
  catch(Exception& ex) {
    ShowMessage(ex.Message);
  }
}
//---------------------------------------------------------------------------

static int throwif(bool cond)
{
  if (cond)
    throw Exception("Thrown from C++");
  return 0;
}

void __fastcall TForm42::Button2Click(TObject *Sender)
{
  try {
    throwif(true);
  }
  catch(Exception& ex) {
    ShowMessage(ex.Message);
  }
}
//---------------------------------------------------------------------------
