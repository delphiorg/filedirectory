#if 1

#include <iostream>
#include <System.IOUtils.hpp>
#include "MethodRef.h"

int main(int argc, char* argv[])
{
  String ext(argc >  1 ? argv[1] : ".cpp");

  TStringDynArray files;
  files = TDirectory::GetFiles(TDirectory::GetCurrentDirectory(),
                               MakeAnonMeth<TDirectory::TFilterPredicate>(
                                [ext](const String Path, const System::Sysutils::TSearchRec &SearchRec) -> bool
                                {
                                  return ExtractFileExt(SearchRec.Name) == ext;
                                }));

  std::cout << "Found " << files.Length << " files with ext: '" << AnsiString(ext) << "'\n";
  for (int i=0; i<files.Length; ++i)
    std::cout << AnsiString(files[i]) << std::endl;
}


#else


#include <iostream>
#include <System.IOUtils.hpp>

class MyFilterPredicate : public TCppInterfacedObject<TDirectory::TFilterPredicate>
{
  String ext;
public:
  MyFilterPredicate(String e) : ext(e)
  {}

  bool __fastcall Invoke(const String Path, const System::Sysutils::TSearchRec &SearchRec)
  {
    return ExtractFileExt(SearchRec.Name) == ext;
  }
};


int main(int argc, char* argv[])
{
  String ext(argc >  1 ? argv[1] : ".cpp");

  TStringDynArray files;
  files = TDirectory::GetFiles(TDirectory::GetCurrentDirectory(),
                               TDirectory::_di_TFilterPredicate(new MyFilterPredicate(ext)));

  std::cout << "Found " << files.Length << " files with ext: '" << AnsiString(ext) << "'\n";
  for (int i=0; i<files.Length; ++i)
    std::cout << AnsiString(files[i]).c_str() << "\n";
}

#endif
